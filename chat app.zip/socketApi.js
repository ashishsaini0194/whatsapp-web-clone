var socket_io = require('socket.io');
var io = socket_io();
var socketApi = {};

socketApi.io = io;

io.sockets.on('connection', function (socket) {
    console.log('A user connected');
    socket.on("Outrage", (data) => {
        console.log(data);
        module.exports.a = data;
        socket.broadcast.emit(data.client, { mess: data.mess, sender: data.sender, senderName: data.senderName });
    })
    // socket.on("hee",{a:"duafhgiushd"})
});

// socketApi.sendNotification = function() {
//     io.sockets.emit('hello', {msg: 'Hello World!'});
// }

module.exports = socketApi;
